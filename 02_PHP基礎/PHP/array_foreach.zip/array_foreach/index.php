<?php
   $products_names = ['人気のGパン', 'タイトなTシャツ', '春のスカート'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="./style.css">
</head>
<body>
  <?php foreach ($products_names as $product_name) :?>
    <div>
      <h1>商品名</h1>
      <span><?php echo $product_name;?></span>
    </div>
  <?php endforeach; ?>
</body>
</html>